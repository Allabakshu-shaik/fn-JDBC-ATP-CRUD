create table PRODUCTS (    
  PRODUCT_NAME    varchar2(100),  
  PRODUCT_COUNT    Integer,  
  constraint pk_emp primary key (PRODUCT_NAME)
)